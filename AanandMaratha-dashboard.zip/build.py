#!/usr/bin/env python3
"""Builds index.html from data/profiles.json for the Anand Maratha interested-profiles dashboard."""
import json, os, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data", "profiles.json")
OUT = os.path.join(HERE, "index.html")

with open(DATA, encoding="utf-8") as f:
    db = json.load(f)

updated = datetime.datetime.now().strftime("%d %b %Y, %I:%M %p")
data_js = json.dumps(db, ensure_ascii=False)

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Anand Maratha — Interested Profiles</title>
<style>
  :root{--brown:#a05a2c;--brown2:#66451c;--cream:#f6f2ed;--card:#fff;--ink:#33271c;--muted:#8a7a6c;--line:#e7dccf;--good:#2e7d32;}
  *{box-sizing:border-box;}
  body{margin:0;background:var(--cream);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;line-height:1.5;}
  header{background:linear-gradient(to right,var(--brown),var(--brown2));color:#fff;padding:22px 26px;}
  header h1{margin:0;font-size:22px;font-weight:600;letter-spacing:.2px;}
  header p{margin:4px 0 0;opacity:.9;font-size:13px;}
  .wrap{max-width:1180px;margin:0 auto;padding:20px 18px 60px;}
  .stats{display:flex;gap:14px;flex-wrap:wrap;margin:18px 0;}
  .stat{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px 18px;min-width:120px;flex:1 1 120px;}
  .stat b{display:block;font-size:24px;color:var(--brown);}
  .stat span{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;}
  .controls{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:20px;}
  .controls input,.controls select{padding:9px 12px;border:1px solid var(--line);border-radius:9px;font-size:14px;background:#fff;color:var(--ink);}
  .controls input{flex:1;min-width:180px;}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));gap:18px;}
  .card{background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 4px 16px rgba(0,0,0,.05);}
  .photoWrap{position:relative;background:#efe7dd;aspect-ratio:4/5;overflow:hidden;}
  .photoWrap img{width:100%;height:100%;object-fit:cover;display:block;}
  .badge{position:absolute;top:10px;right:10px;background:rgba(160,90,44,.95);color:#fff;font-weight:600;font-size:13px;padding:5px 10px;border-radius:20px;}
  .contacted{position:absolute;top:10px;left:10px;background:rgba(46,125,50,.95);color:#fff;font-size:11px;font-weight:600;padding:4px 9px;border-radius:20px;letter-spacing:.3px;}
  .nav{position:absolute;bottom:8px;left:0;right:0;display:flex;justify-content:center;gap:6px;}
  .dot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.6);border:1px solid rgba(0,0,0,.2);cursor:pointer;}
  .dot.on{background:#fff;}
  .arrow{position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.35);color:#fff;border:none;width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:16px;}
  .arrow.l{left:8px;} .arrow.r{right:8px;}
  .body{padding:14px 16px 16px;}
  .nm{font-size:17px;font-weight:600;margin:0;}
  .rg{font-size:12px;color:var(--muted);margin:2px 0 10px;}
  .chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;}
  .chip{background:var(--cream);border:1px solid var(--line);border-radius:20px;padding:3px 9px;font-size:12px;}
  .gun{font-size:12px;color:var(--brown2);margin-bottom:10px;cursor:help;}
  details{border-top:1px solid var(--line);padding-top:8px;margin-top:4px;}
  details summary{cursor:pointer;font-size:13px;font-weight:600;color:var(--brown);outline:none;list-style:none;padding:4px 0;}
  details summary::-webkit-details-marker{display:none;}
  details summary:before{content:"▸ ";}
  details[open] summary:before{content:"▾ ";}
  .sec{margin:8px 0;}
  .sec h4{margin:8px 0 4px;font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);}
  table.kv{width:100%;border-collapse:collapse;font-size:13px;}
  table.kv td{padding:3px 4px;vertical-align:top;border-bottom:1px solid #f2ece3;}
  table.kv td.k{color:var(--muted);width:42%;}
  .contact{background:#f1f8f1;border:1px solid #cfe6cf;border-radius:10px;padding:10px 12px;margin-top:10px;font-size:13px;}
  .contact h4{margin:0 0 6px;color:var(--good);font-size:12px;text-transform:uppercase;letter-spacing:.5px;}
  .contact a{color:var(--brown2);}
  .nocontact{background:#fdf6ee;border:1px dashed var(--brown);border-radius:10px;padding:10px 12px;margin-top:10px;font-size:12px;color:var(--brown2);}
  .actions{display:flex;gap:8px;margin-top:12px;}
  .btn{flex:1;text-align:center;text-decoration:none;font-size:13px;font-weight:600;padding:9px 10px;border-radius:9px;border:1px solid var(--brown);color:var(--brown);background:#fff;}
  .btn.primary{background:var(--brown);color:#fff;}
  footer{max-width:1180px;margin:0 auto;padding:0 18px 40px;color:var(--muted);font-size:12px;}
  @media (max-width:600px){
    header{padding:16px 16px;}
    header h1{font-size:18px;}
    header p{font-size:12px;}
    .wrap{padding:14px 12px 50px;}
    .stats{gap:8px;margin:12px 0;}
    .stat{padding:10px 12px;min-width:0;flex:1 1 calc(50% - 8px);}
    .stat b{font-size:20px;}
    .controls{flex-direction:column;align-items:stretch;gap:8px;}
    .controls input,.controls select{width:100%;font-size:16px;}
    .grid{grid-template-columns:1fr;gap:14px;}
    .arrow{width:40px;height:40px;font-size:20px;}
    .dot{width:11px;height:11px;}
    details summary{padding:8px 0;font-size:14px;}
    .btn{padding:12px 10px;}
    table.kv td{padding:5px 4px;}
  }
  @media (hover:none){ .gun span{display:none;} }
</style>
</head>
<body>
<header>
  <h1>Anand Maratha — Profiles Who Expressed Interest</h1>
  <p>For __WHO__ · Updated __UPDATED__</p>
</header>
<div class="wrap">
  <div class="stats" id="stats"></div>
  <div class="controls">
    <input id="q" placeholder="Search name, education, city, occupation…"/>
    <select id="sort">
      <option value="match">Sort: Match % (high→low)</option>
      <option value="gun">Sort: Gun Milan (high→low)</option>
      <option value="new">Sort: Newest first</option>
    </select>
    <select id="filter">
      <option value="all">Show: All</option>
      <option value="contact">Show: Contact available</option>
      <option value="pending">Show: Awaiting interest</option>
    </select>
  </div>
  <div class="grid" id="grid"></div>
</div>
<footer>
  Photos load directly from anandmaratha.com — if a photo is blank, open the site and sign in, then refresh this page.
  Contact details appear automatically once you have expressed interest and the office has sent them.
</footer>
<script>
const DB = __DATA__;
const P = DB.profiles;
function age(dob){var m=dob.match(/(\\d{2})\\/(\\d{2})\\/(\\d{4})/);if(!m)return null;var d=new Date(m[3],m[2]-1,m[1]);var t=new Date();var a=t.getFullYear()-d.getFullYear();if(t.getMonth()<d.getMonth()||(t.getMonth()==d.getMonth()&&t.getDate()<d.getDate()))a--;return a;}
function gv(arr,key){for(var i=0;i<arr.length;i++){if(arr[i][0]==key)return arr[i][1];}return "";}
function gunNum(g){var m=(g||"").match(/([\\d.]+)/);return m?parseFloat(m[1]):0;}
function esc(s){return (s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function kvtable(arr){var r="<table class='kv'>";arr.forEach(function(p){if(p[1])r+="<tr><td class='k'>"+esc(p[0])+"</td><td>"+esc(p[1])+"</td></tr>";});return r+"</table>";}

function card(p){
  var a=age(gv(p.details,"Date Of Birth"));
  var chips=[];
  if(a)chips.push(a+" yrs");
  var h=gv(p.details,"Height"); if(h)chips.push(h);
  var ed=gv(p.details,"Education"); if(ed)chips.push(ed.length>22?ed.slice(0,22)+"…":ed);
  var oc=gv(p.details,"Occupation");
  var loc=gv(p.family,"Parents Residing In"); if(loc)chips.push("📍"+loc);
  var photoHtml="";
  var ph=p.photos&&p.photos.length?p.photos:["https://www.anandmaratha.com/no_imgf.jpg"];
  ph.forEach(function(u,i){photoHtml+="<img data-i='"+i+"' src='"+u+"' style='"+(i?"display:none":"")+"' onerror=\\"this.onerror=null;this.src='https://www.anandmaratha.com/no_imgf.jpg'\\"/>";});
  var navHtml="";
  if(ph.length>1){
    navHtml="<button class='arrow l' onclick='nav(this,-1)'>‹</button><button class='arrow r' onclick='nav(this,1)'>›</button><div class='nav'>";
    ph.forEach(function(u,i){navHtml+="<span class='dot"+(i?"":" on")+"' onclick='go(this,"+i+")'></span>";});
    navHtml+="</div>";
  }
  var contactedTag=p.contact?"<span class='contacted'>✓ CONTACT</span>":"";
  var contactHtml;
  if(p.contact){
    var c=p.contact, phones=(c.phones||"").split(",").map(function(x){x=x.trim();return x?"<a href='tel:"+x+"'>"+x+"</a>":"";}).filter(Boolean).join(", ");
    contactHtml="<div class='contact'><h4>Contact Details</h4>"+
      "<div><b>"+esc(c.name)+"</b></div>"+
      (c.address?"<div>"+esc(c.address)+"</div>":"")+
      (phones?"<div>📞 "+phones+"</div>":"")+
      (c.email?"<div>📧 <a href='mailto:"+esc(c.email)+"'>"+esc(c.email)+"</a></div>":"")+
      "</div>";
  } else {
    contactHtml="<div class='nocontact'>No contact yet. Click <b>Express interest</b> to open the profile and tap the green <b>INTERESTED</b> button — contact details will arrive by email.</div>";
  }
  return "<div class='card' data-blob='"+esc((p.surname+" "+p.regno+" "+ed+" "+oc+" "+loc).toLowerCase())+"' data-match='"+p.match+"' data-gun='"+gunNum(p.gun)+"' data-contact='"+(p.contact?1:0)+"' data-seen='"+p.firstSeen+"'>"+
    "<div class='photoWrap'>"+photoHtml+"<span class='badge'>"+p.match+"% match</span>"+contactedTag+navHtml+"</div>"+
    "<div class='body'>"+
      "<p class='nm'>"+esc(p.surname)+"</p>"+
      "<p class='rg'>"+p.regno+" · DOB "+esc(gv(p.details,"Date Of Birth"))+"</p>"+
      "<div class='chips'>"+chips.map(function(c){return "<span class='chip'>"+esc(c)+"</span>";}).join("")+"</div>"+
      (oc?"<div style='font-size:13px;margin-bottom:8px'>💼 "+esc(oc)+"</div>":"")+
      "<div class='gun' title='"+esc(p.gunBreak)+"'>★ Gun Milan: "+esc(p.gun)+" <span style='color:var(--muted)'>(hover for breakdown)</span></div>"+
      "<details><summary>Full profile, family &amp; expectations</summary>"+
        "<div class='sec'><h4>Profile Details</h4>"+kvtable(p.details)+"</div>"+
        "<div class='sec'><h4>Family Background</h4>"+kvtable(p.family)+"</div>"+
        "<div class='sec'><h4>Expectation</h4>"+kvtable(p.expectation)+"</div>"+
      "</details>"+
      contactHtml+
      "<div class='actions'><a class='btn' href='"+p.link+"' target='_blank'>View live profile</a><a class='btn primary' href='"+p.link+"' target='_blank'>Express interest →</a></div>"+
    "</div></div>";
}
function nav(btn,dir){var w=btn.closest('.photoWrap');var imgs=w.querySelectorAll('img');var dots=w.querySelectorAll('.dot');var cur=0;imgs.forEach(function(im,i){if(im.style.display!=='none')cur=i;});var n=(cur+dir+imgs.length)%imgs.length;show(w,n);}
function go(dot,i){show(dot.closest('.photoWrap'),i);}
function show(w,n){w.querySelectorAll('img').forEach(function(im,i){im.style.display=i===n?'block':'none';});w.querySelectorAll('.dot').forEach(function(d,i){d.classList.toggle('on',i===n);});}

function render(){
  var q=document.getElementById('q').value.toLowerCase().trim();
  var sort=document.getElementById('sort').value;
  var filt=document.getElementById('filter').value;
  var list=P.slice();
  list.sort(function(a,b){
    if(sort==='match')return b.match-a.match;
    if(sort==='gun')return gunNum(b.gun)-gunNum(a.gun);
    return (b.firstSeen||'').localeCompare(a.firstSeen||'');
  });
  var html=list.map(card).join("");
  var g=document.getElementById('grid');g.innerHTML=html;
  Array.prototype.forEach.call(g.children,function(el){
    var ok=true;
    if(q&&el.getAttribute('data-blob').indexOf(q)<0)ok=false;
    if(filt==='contact'&&el.getAttribute('data-contact')!=='1')ok=false;
    if(filt==='pending'&&el.getAttribute('data-contact')!=='0')ok=false;
    el.style.display=ok?'':'none';
  });
}
function stats(){
  var withC=P.filter(function(p){return p.contact;}).length;
  var top=Math.max.apply(null,P.map(function(p){return p.match;}));
  document.getElementById('stats').innerHTML=
    "<div class='stat'><b>"+P.length+"</b><span>Profiles</span></div>"+
    "<div class='stat'><b>"+withC+"</b><span>Contact ready</span></div>"+
    "<div class='stat'><b>"+(P.length-withC)+"</b><span>Awaiting interest</span></div>"+
    "<div class='stat'><b>"+top+"%</b><span>Top match</span></div>";
}
document.getElementById('q').addEventListener('input',render);
document.getElementById('sort').addEventListener('change',render);
document.getElementById('filter').addEventListener('change',render);
stats();render();
</script>
</body>
</html>"""

HTML = HTML.replace("__WHO__", db.get("generatedFor","")).replace("__UPDATED__", updated).replace("__DATA__", data_js)
with open(OUT, "w", encoding="utf-8") as f:
    f.write(HTML)
print("Wrote", OUT, "with", len(db["profiles"]), "profiles")
